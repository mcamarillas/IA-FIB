(load ontologia.clp)
(load-instances ontologia.pins)
(load reglas.clp)
